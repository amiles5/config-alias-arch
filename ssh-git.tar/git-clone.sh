git clone git@github.com:amiles5/dot_config_noctalia.git
sudo pacman -S --needed base-devel git
git clone https://aur.archlinux.org/paru.git
cd paru
makepkg -si
cd ~/dot_config_noctalia
sudo pacman -S --needed - < pkglist_native.txt
paru -S --needed - < pkglist_foreign.txt
#nix flake update --flake ~/ayana-nixos ; sudo nixos-rebuild switch --impure --flake ~/ayana-nixos#ayana

